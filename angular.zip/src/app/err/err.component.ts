import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-err',
  templateUrl: './err.component.html',
  styleUrls: ['./err.component.scss']
})
export class ErrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
